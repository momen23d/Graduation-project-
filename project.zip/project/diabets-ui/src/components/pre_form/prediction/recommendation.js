import axios from 'axios';
import jsPDF from 'jspdf';

export const recommendationHandler = async (token) => {
  try {
    const recommendationApiUrl = 'http://127.0.0.1:3001/users/recommend'; // Update with your backend recommendation API URL
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const response = await axios.post(recommendationApiUrl, {}, { headers });

    if (response.data) {
      const meals = response.data.meals;
      const doc = new jsPDF();
      
      doc.setFontSize(18);
      doc.text('Meal Recommendations', 10, 20);
      doc.setFontSize(12);
      let yPosition = 30; // Start position for the text
      const pageHeight = doc.internal.pageSize.height;
      const lineHeight = 10;

      meals.forEach((meal, index) => {
        if (yPosition + lineHeight * 10 > pageHeight) {
          doc.addPage();
          yPosition = 20; // Reset y position for the new page
        }

        doc.setFontSize(14);
        doc.text(`Name: ${meal.name}`, 10, yPosition);
        yPosition += lineHeight;

        doc.setFontSize(12);
        doc.text(`Nutrient: ${meal.nutrient}`, 10, yPosition);
        yPosition += lineHeight;

        doc.text(`Disease: ${meal.disease.join(', ')}`, 10, yPosition);
        yPosition += lineHeight;

        doc.text(`Diet: ${meal.diet}`, 10, yPosition);
        yPosition += lineHeight;

        doc.text(`Ingredients:`, 10, yPosition);
        yPosition += lineHeight;
        meal.ingredients.forEach(ingredient => {
          doc.text(`- ${ingredient}`, 15, yPosition);
          yPosition += lineHeight;
        });

        doc.text(`Steps:`, 10, yPosition);
        meal.steps.forEach(step => {
          yPosition += lineHeight;
          doc.text(`- ${step}`, 15, yPosition);
        });

        yPosition += lineHeight * 2; // Add some space between meals
      });

      doc.save('recommendations.pdf');
      console.log('PDF generation initiated');
    } else {
      console.log('No recommendations found');
    }
  } catch (error) {
    console.error('Error in recommendationHandler:', error);
    // Handle error
  }
};
