/* Replace with your SQL commands */
DROP TABLE IF EXISTS users;