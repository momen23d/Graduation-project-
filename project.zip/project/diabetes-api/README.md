## Ai 

Folder => (requirements.txt , app.py)
###  step 0 : install python `python --version`

###  step 1 : install requirenments 

`pip install -r requirements.txt`

### how to start application:
 `python app.py`

## backend
###  step 1 : install nodejs and npm 
`https://nodejs.org/en/download`
- downlaod nodejs , npm 
how can i check : ` node -v`, `npm -v`

### how to start application:
- `npm install`
- `npm run start`

## front end
`https://nodejs.org/en/download`
- downlaod nodejs , npm 
how can i check : ` node -v`, `npm -v`
### how to start application:
- `npm install`
- `npm run start`